package com.tutuit.a1.data.network;

public class Constant {
    // 服务器地址
    public final static String RetrofitBaseUrl = "http://wyyapi.itaemobile.top";
    public static final int TYPE_LOCAL = 1;
    public static final int TYPE_LINE = 2;
}
