package com.tutuit.a1.data.network;

public class DataRepository {

}
