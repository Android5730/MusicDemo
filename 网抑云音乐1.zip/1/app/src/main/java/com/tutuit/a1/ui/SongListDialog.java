package com.tutuit.a1.ui;

import android.app.Dialog;
import android.content.Context;

import androidx.annotation.NonNull;

// 播放列表弹窗
public class SongListDialog extends Dialog {

    public SongListDialog(@NonNull Context context) {
        super(context);
    }
}
